# 制药英语每日一词 · Cloudflare Pages 部署指南

> 目标：将 H5 学习页面部署到 Cloudflare Pages，获得 pages.dev 短链接，供微信公众号「阅读原文」跳转。

---

## 前置准备

| 需要 | 说明 |
|------|------|
| GitHub 账号 | 创建代码仓库，免费 |
| Cloudflare 账号 | 免费注册 workers.cloudflare.com |
| 部署包 | 本文件夹 `pharma-h5-deploy/` |

---

## Step 1：创建 GitHub 仓库

1. 登录 GitHub（github.com）
2. 点击右上角 **+** → **New repository**
3. 填写：
   - **Repository name**：`pharma-english-daily`
   - **Description**：`制药英语每日一词 H5学习中心`
   - **Private**（私有）或 Public 均可
   - ✅ **Add a README file**
4. 点击 **Create repository**

---

## Step 2：上传部署文件到仓库

### 方法A：网页上传（最简单）

1. 进入刚创建的仓库页面
2. 点击 **Add file** → **Upload files**
3. 将 `pharma-h5-deploy/` 文件夹内的 **所有内容** 拖入上传区域：
   - `index.html`（根目录）
   - `episode/` 文件夹（包含所有期数 HTML）
4. 填写 Commit message：`Initial commit - H5 learning center`
5. 点击 **Commit changes**

### 方法B：GitHub Desktop（推荐批量管理）

1. 下载 GitHub Desktop：desktop.github.com
2. Clone 刚创建的仓库到本地
3. 将 `pharma-h5-deploy/` 内所有文件复制到仓库文件夹
4. 在 GitHub Desktop 中 Commit → Push

---

## Step 3：连接 Cloudflare Pages

1. 登录 [Cloudflare Dashboard](https://dash.cloudflare.com)
2. 左侧菜单 → **Workers & Pages**
3. 点击 **Create application**
4. 选择 **Pages** → **Connect to Git**

### 配置构建

| 设置项 | 值 |
|--------|-----|
| GitHub 仓库 | 选择 `your-username/pharma-english-daily` |
| 生产分支 | `main` |
| 构建命令 | （留空，静态HTML无需构建） |
| 构建输出目录 | `/`（斜杠，表示根目录） |
| 环境变量 | 无需设置 |

5. 点击 **Save and Deploy**

---

## Step 4：等待部署完成

- 部署状态显示在 Pages 面板
- 通常 1-3 分钟完成
- 部署成功后获得地址：`https://xxx.pages.dev`

---

## Step 5：绑定自定义域名（可选）

如果有自己的域名（如 `english.yourdomain.com`）：

1. 在 Cloudflare Pages → 你的项目 → **Custom domains**
2. 添加域名，按提示配置 DNS
3. 等待 SSL 证书自动签发

---

## Step 6：获取公众号「阅读原文」链接

| 场景 | 链接格式 |
|------|---------|
| 直接用 pages.dev | `https://xxx.pages.dev` |
| 绑定自定义域名 | `https://english.yourdomain.com` |
| 推荐（可追踪） | `https://xxx.pages.dev/episode/episode-001-deviation.html` |

> 💡 **推荐做法**：每期文章链接指向具体那期页面，如 `pages.dev/episode/episode-001-deviation.html`

---

## 日常更新流程

每生成一期新内容：
1. 在 `pharma-h5-deploy/episode/` 添加新 HTML 文件（如 `episode-002-oos.html`）
2. 更新 `pharma-h5-deploy/index.html`，添加新一期入口链接
3. 上传到 GitHub → Cloudflare Pages **自动检测到变更** → 自动重新部署

---

## 文件夹结构（部署包）

```
pharma-h5-deploy/
├── index.html                          ← 学习中心首页
└── episode/
    └── episode-001-deviation.html     ← 第001期 Deviation
```

后续期数文件名格式：`episode-XXX-关键词.html`

---

## 常见问题

| 问题 | 解决方案 |
|------|---------|
| 部署失败 | 检查 GitHub 仓库是否有 `index.html` |
| 页面样式乱 | 确认 CSS 内联在 HTML 中（已配置好） |
| 发音不工作 | 手机浏览器需允许语音，Chrome/Safari 支持较好 |
| 微信内打不开 | pages.dev 域名需已备案，或使用自定义已备案域名 |
| 想加公众号二维码 | 在 `index.html` 页脚添加二维码图片 |

---

## 关键优势

| 对比项 | 方案优势 |
|--------|---------|
| 国内访问 | Cloudflare CDN 节点覆盖好，速度优于 GitHub Pages |
| 中文URL | 完全支持，无乱码 |
| 免费额度 | 无限流量，无构建限制 |
| 自动化 | GitHub 推送 → 自动部署，无需手动操作 |
